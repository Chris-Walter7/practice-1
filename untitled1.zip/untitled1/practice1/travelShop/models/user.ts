export interface IUser {
    name: string,
    cardNumber: string,
    birthDate: Date
}