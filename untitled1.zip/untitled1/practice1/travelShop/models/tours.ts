export interface ITours {
    description: "From the south to the center of the country"
    id: "1"
    img: "ocean.jpg"
    name: "Mexico"
    price: "€2,192"
    tourOperator: "LocalAdventures"
}