export interface IUser { //чтобы можно было импортировать пишем export
    userid: string;
    name:string;
    gender: string;
}

export type GenderTypes = 'man' | 'woman';
export type UserTypes = 'Admin' | 'User' | 'SuperAdmin'